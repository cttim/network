two programs are java program

Make version is GUN Make 3.81

Compiler version is javac 1.6.0_27

1 Run the make command to compile two java programs

2 Run the nEmulator in the format of "./nEmulator-linux386 port1 host2 port4 por3 host3 port2 1 0.2 0"

3 Run the receiver in the format of "java receiver host1 port3 port4 <outputfile>"

4 Run the sender in the format of "java sender host1 port1 port2 <input file>"

5 After transmission you will get three log files: ack.log, arrival.log, seqnum.log and you will also get a outputfile which should be same as input file

